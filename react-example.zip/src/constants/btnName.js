export const btnName = [
  "home",
  "project1",
  "project2",
  "project3",
  "project4",
];