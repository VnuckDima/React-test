import HeaderCont from "./layouts/HeaderCont";

function App() {

  return (
    <>
      <HeaderCont />
    </>
  );
}

export default App;
