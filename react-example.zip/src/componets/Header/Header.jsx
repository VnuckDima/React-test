import "./Header.css";

function Header({ children }) {
  return <header className="header-page">{children}</header>;
}

export default Header;
