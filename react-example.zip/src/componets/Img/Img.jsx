import React from "react";
import ImgIcon from "../../assets/images/img-icon.jpg";

function Img() {
  return (
    <div>
      <img src={ImgIcon} alt="img" width="90" />
    </div>
  );
}

export default Img;
